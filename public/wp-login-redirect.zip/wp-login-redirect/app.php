<?php
/**
* Plugin Name: Login Redirect 
* Plugin URI: https://yasaryousuf.me/
* Description: Redirect user to log in page if not logged in.
* Version: 1.0
* Author: Yasar Yousuf
* Author URI: https://yasaryousuf.me/
**/